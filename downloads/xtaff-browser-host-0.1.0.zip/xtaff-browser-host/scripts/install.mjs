import { createHash } from 'node:crypto';
import { readFile, mkdir, writeFile, chmod, rm } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
const base = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const storeId = 'ojklapkgpijghmlifajbmldghnhmejfh';
const ids = [storeId];
if (!process.argv.includes('--store')) {
  const manifest = JSON.parse(await readFile(resolve(base, '../../apps/browser_extension/manifest.json'), 'utf8'));
  const hash = createHash('sha256').update(Buffer.from(manifest.key, 'base64')).digest().subarray(0, 16);
  ids.unshift([...hash].flatMap(x => [x >> 4, x & 15]).map(x => String.fromCharCode(97 + x)).join(''));
}
const allowedOrigins = ids.map(extensionId => `chrome-extension://${extensionId}/`);
const paths = process.platform === 'darwin' ? [join(homedir(), 'Library/Application Support/Google/Chrome/NativeMessagingHosts'), join(homedir(), 'Library/Application Support/Chromium/NativeMessagingHosts'), join(homedir(), 'Library/Application Support/Google/ChromeForTesting/NativeMessagingHosts')] : [join(homedir(), '.config/google-chrome/NativeMessagingHosts'), join(homedir(), '.config/chromium/NativeMessagingHosts'), join(homedir(), '.config/google-chrome-for-testing/NativeMessagingHosts')];
if (process.platform === 'win32') {
  const target = join(homedir(), '.xtaff-browser');
  const manifestFile = join(target, 'com.xtaff.browser.json');
  const host = join(target, 'native-host.cmd');
  const key = 'HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\com.xtaff.browser';
  if (process.argv.includes('--uninstall')) {
    try { execFileSync('reg.exe', ['delete', key, '/f'], { stdio: 'ignore' }); } catch { /* already absent */ }
    await rm(manifestFile, { force: true }); await rm(host, { force: true });
    console.log('Native host uninstalled');
  } else {
    await mkdir(target, { recursive: true });
    await writeFile(host, `@echo off\r\n"${process.execPath}" "${join(base, 'dist/host.js')}"\r\n`);
    await writeFile(manifestFile, JSON.stringify({ name: 'com.xtaff.browser', description: 'Xtaff browser local host', path: host, type: 'stdio', allowed_origins: allowedOrigins }, null, 2));
    execFileSync('reg.exe', ['add', key, '/ve', '/t', 'REG_SZ', '/d', manifestFile, '/f'], { stdio: 'ignore' });
    console.log(`Native host installed for extensions ${ids.join(', ')}`);
  }
  process.exit(0);
}
const target = join(homedir(), '.xtaff-browser');
const shellQuote = s => `'${s.replaceAll("'", "'\\''")}'`;
if (process.argv.includes('--uninstall')) {
  for (const path of paths) await rm(join(path, 'com.xtaff.browser.json'), { force: true });
  await rm(join(target, 'native-host'), { force: true });
  console.log('Native host uninstalled');
} else {
  await mkdir(target, { recursive: true, mode: 0o700 });
  const host = join(target, 'native-host');
  await writeFile(host, `#!/bin/sh\nexec ${shellQuote(process.execPath)} ${shellQuote(join(base, 'dist/host.js'))}\n`, { mode: 0o700 });
  await chmod(host, 0o700);
  for (const path of paths) {
    await mkdir(path, { recursive: true });
    await writeFile(join(path, 'com.xtaff.browser.json'), JSON.stringify({ name: 'com.xtaff.browser', description: 'Xtaff browser local host', path: host, type: 'stdio', allowed_origins: allowedOrigins }, null, 2));
  }
  console.log(`Native host installed for extensions ${ids.join(', ')}`);
}
