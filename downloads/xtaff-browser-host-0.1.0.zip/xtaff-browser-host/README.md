# Xtaff Browser local host

This package connects the Xtaff Browser Chrome extension to a local MCP client. It does not connect to an Xtaff cloud service. It requires desktop Chrome 125 or newer and Node.js 22 or newer. macOS is tested; Linux and Windows are not yet verified.

1. Extract this folder to a permanent location. Do not move or delete it after installation.
2. In a terminal opened in this folder, run:

   ```sh
   node scripts/install.mjs --store
   ```

   This registers the native host for the Chrome Web Store extension ID. On Windows, run the same command in a terminal. If the folder or Node installation moves, run the command again.
3. Configure your MCP client to run Node with the **absolute path** to `dist/index.js` in this folder. For example, in Codex `~/.codex/config.toml`:

   ```toml
   [mcp_servers.xtaff-browser]
   command = "/absolute/path/to/node"
   args = ["/absolute/path/to/xtaff-browser-host/dist/index.js"]
   ```

   For Claude Code, use `claude mcp add --scope user --transport stdio xtaff-browser -- /absolute/path/to/node /absolute/path/to/xtaff-browser-host/dist/index.js`. Replace both paths with your actual paths. Run `node -p 'process.execPath'` to find Node.
4. Restart the MCP client. Install the Xtaff Browser extension from Chrome Web Store, open its popup, and approve sites when requested. Only tabs in the Xtaff group can be controlled. The assistant may send data returned by the extension to its configured model provider. See https://qiweiview.github.io/xtaff-public/browser-privacy.html.

To unregister the host, run `node scripts/install.mjs --store --uninstall`, then remove this folder. Removing the extension clears its local extension storage.
